<form action="" id="formbarangmutasi" method="post">
<div class="row">
    
        <div class="col-md-7" id="selectlokasixx">
            
                <?php echo csrf_field(); ?>
            <label for="">Nomor Inventaris</label>
                    <select class="form-control single-select" name="kd_inventaris">
                                <option>Nama barang -- Type barang</option>
                                <?php $__currentLoopData = $data_brg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>">
                                                -<?php echo e($item->nama_barang); ?> -- <?php echo e($item->type); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                
        </div>
        <div class="col-md-5" id="selectlokasixx">
            
            <label for="">Lokasi Tujuan</label>
                    <select class="form-control single-select" name="kd_lokasi">
                                <option>Cari Lokasi Tujuan</option>
                                <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lokasi->kd_lokasi); ?>">
                                                -<?php echo e($lokasi->nama_lokasi); ?> -- 
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                
        </div>
   
    
</div>
</form>
<div class="row pt-4" style="float: right;">
    <div class="col-12">
        <button class="btn btn-success btn-sm" id="kliktambahbrgmutasi" data-url="<?php echo e(route('kliktambahbrgmutasi',['id'=>$id])); ?>"><i class="fa fa-save"> Simpan</i></button>
        <button class="btn btn-danger btn-sm"><i class="fa fa-back"> Batal</i></button>
    </div>
</div>
<script>
    $(document).ready(function() {
        $('.single-select').select2();

    });
</script><?php /**PATH D:\Kantor\tes\app_serve\resources\views/admin/form/selectlokasi.blade.php ENDPATH**/ ?>