<div class="row">
    
    <div class="col-md-7" id="selectlokasixx">
        <form action="" id="formbarangmusnah" method="post">
            <?php echo csrf_field(); ?>
        <label for="">Nomor Inventaris</label>
                <select class="form-control single-select" name="kd_inventaris">
                            <option>Nama barang -- Type barang</option>
                            <?php $__currentLoopData = $data_brg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>">
                                            -<?php echo e($item->nama_barang); ?> -- <?php echo e($item->type); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>
    </div>
    <div class="col-md-5">
        <label for="">Action</label><br>
        <button class="btn btn-success btn-sm" id="kliktambahbrgmusnah" data-url="<?php echo e(route('kliktambahbrgmusnah',['id'=>$id])); ?>"><i class="fa fa-save"> Simpan</i></button>
        <button class="btn btn-danger btn-sm"><i class="fa fa-close"> Tutup</i></button>
    </div>

</div>
<script>
$(document).ready(function() {
    $('.single-select').select2();

});
</script><?php /**PATH D:\Kantor\tes\app_serve\resources\views/admin/form/selectlokasi1.blade.php ENDPATH**/ ?>