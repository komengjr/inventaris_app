<!DOCTYPE html>
<html lang="en">
<head>
 
    <title>Document</title>
    
</head>
<style>
  @page  { 
    margin-left : 10px;
    margin-top: 5px;
   }
body { margin: 0px; }
  p{
  padding: 0px;
	background: rgb(255, 255, 255);
  text-align: center;
	/* height: 80px; */
  font-size: 12px;
  text-size-adjust: auto;
  font-family: "Copperplate", "Courier New", Monospace;
	width: 180px;
	margin-top: 0px;
  margin-bottom: 20px;
}
hr{
  width: 180px;
}

</style>
<body >
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
      
      <div class="row" style="width: 180px; height: 115px;">
                
        
        <p></p>
        <strong><p style="font-size: 13px;"><?php echo e($data->nama_peserta); ?></p></strong> 
        <br>
        <strong><p><?php echo e($data->status); ?></p></strong> 
        <hr>
      </div>
 
       
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
       
    
</body>
</html><?php /**PATH D:\Kantor\tes\app_serve\resources\views/peserta.blade.php ENDPATH**/ ?>