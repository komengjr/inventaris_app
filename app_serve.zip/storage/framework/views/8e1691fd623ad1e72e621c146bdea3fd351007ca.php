<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" >
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/fontawesome.min.css" integrity="sha512-xX2rYBFJSj86W54Fyv1de80DWBq7zYLn2z0I9bIhQG+rxIF6XVJUpdGnsNHWRa6AvP89vtFupEPDP8eZAtu9qA==" crossorigin="anonymous" referrerpolicy="no-referrer" />




<style>
    .card-footer, .progress {
        display: none;
    }
</style>

<body>

<div class="container pt-4">
    <div class="row justify-content-center">
        <div class="col-md-8" id="inputdata">
            <div class="card">
                <div class="card-header text-center">
                    <h5>Upload Video</h5>
                </div>

            
                    <img src="" id="videoPreview" alt="" style="width: 100%; height: auto">
                </div>
                <div class="card-footer p-4" >
                    <input id="link" type="text" name="link" class="form-control" value=""> <br>
                    <button class="btn btn-success" type="submit">Simpan</button>
                </div>
            </form> --}}
            <div id="upload-container" class="text-center">
                
                <input type="file" name="" id="browseFile">
            </div>
            <hr>
            <?php if(session()->has('alert-success')): ?>
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <div class="alert-icon contrast-alert">
                    <i class="fa fa-check"></i>
                    </div>
                    <div class="alert-message">
                        <span><strong>Success!</strong>  <?php echo e(session()->get('alert-success')); ?></span>
                    </div>
                </div>
            <?php endif; ?>
            </div>

        </div>
        <div class="col-md-12 pt-4">
            <div class="table-responsive">
                <table class="table ">
                    <thead>
                        <tr>
                            <th>no</th>
                            <th>Title</th>
                            <th>deskripsi</th>
                            <th width="150">option</th>
                        </tr>
                    </thead>
                    
                </table>
            </div>
        </div>
    </div>
</div>

<!-- jQuery -->


<!-- Bootstrap JS Bundle with Popper -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/script.js/2.1.1/script.min.js" integrity="sha512-oM6Bv767uUJZcy+SqCTP2rkHtKlivWNQ5+PPhhDwkY8FtNj4bq1xvNCB9NB3WkBa1KiY7P5a7/yfSONl5TYSPQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Resumable JS -->
<script src="https://cdn.jsdelivr.net/npm/resumablejs@1.1.0/resumable.min.js"></script>

<script type="text/javascript">
    let browseFile = $('#browseFile');
    let resumable = new Resumable({
        target: '<?php echo e(route('files.upload.large')); ?>',
        query:{_token:'<?php echo e(csrf_token()); ?>'} ,// CSRF token
        fileType: ['jpg','png'],
        headers: {
            'Accept' : 'application/json'
        },
        testChunks: false,
        throttleProgressCallbacks: 1,
    });

    resumable.assignBrowse(browseFile[0]);

    resumable.on('fileAdded', function (file) { // trigger when file picked
        showProgress();
        resumable.upload() // to actually start uploading.
    });

    resumable.on('fileProgress', function (file) { // trigger when file progress update
        updateProgress(Math.floor(file.progress() * 100));
    });

    resumable.on('fileSuccess', function (file, response) { // trigger when file upload complete
        response = JSON.parse(response)
        $('#videoPreview').attr('src', response.path);
        $('#link').attr('value', response.filename);
        $('.card-footer').show();
        $('#browseFile').hide();
    });

    resumable.on('fileError', function (file, response) { // trigger when there is any error
        alert('file uploading error.')
    });


    let progress = $('.progress');

    function showProgress() {
        progress.find('.progress-bar').css('width', '0%');
        progress.find('.progress-bar').html('0%');
        progress.find('.progress-bar').removeClass('bg-info');
        progress.show();
    }

    function updateProgress(value) {
        progress.find('.progress-bar').css('width', ` ${value}%`)
        progress.find('.progress-bar').html(`${value}%`)
    }

    function hideProgress() {
        progress.hide();
    }
</script>


<script>
    $(document).ready(function(){
        $(document).on('click', '#editvideo', function(e){
            e.preventDefault();
            var url = $(this).data('url');
            $('#inputdata').html("<br><br><br><img src='../cdn0/pu.gif'  style='display: block; margin: auto;'>");
            $.ajax({
                url: url,
                type: 'GET',
                dataType: 'html'
            })
            .done(function(data){
                $('#inputdata') .html(data);
            })
            .fail(function(){
                $('#inputdata').html('<i class="fa fa-info-sign"></i> Something went wrong, Please try again...');
            });
        });
    });

    $(document).ready(function(){
        $(document).on('click', '#showdata', function(e){
            e.preventDefault();
            var url = $(this).data('url');
            $('#inputdata').html("<br><br><br><img src='../cdn0/pu.gif'  style='display: block; margin: auto;'>");
            $.ajax({
                url: url,
                type: 'GET',
                dataType: 'html'
            })
            .done(function(data){
                $('#inputdata') .html(data);
            })
            .fail(function(){
                $('#inputdata').html('<i class="fa fa-info-sign"></i> Something went wrong, Please try again...');
            });
        });
    });
</script>
</body>
</html>
<?php /**PATH D:\Kantor\tes\app_serve\resources\views/welcome.blade.php ENDPATH**/ ?>