<!DOCTYPE html>
<html lang="en">
<head>
 
    <title>Print Barcode</title>
    
</head>
<style>
  @page  { 
    margin-left : 25px;
    margin-top: 5px;
   }
body { margin: 0px; }
  p{
  padding: 0px;
	background: rgb(255, 255, 255);
  text-align: center;
	/* height: 80px; */
  font-size: 7px;
  text-size-adjust: auto;
  font-family: "Copperplate", "Courier New", Monospace;
	width: 85px;
	margin-top: 0px;
  margin-bottom: 10px;
}

</style>
<body >
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
    <?php if($data->kd_lokasi == "-"): ?>
        
    <?php else: ?>
      <div class="row" style="border: dotted;width: 85px; height: 95px;">
                
        <img src="data:image/png;base64, <?php echo base64_encode(QrCode::format('svg')->size(85)->errorCorrection('H')->generate(url('view', []).'/'.substr($data->kd_inventaris,0,2).'/'.$data->kd_cabang.'/'.$data->kd_inventaris.'/'.$data->id)); ?>">
        <strong><p><?php echo e($data->nama_barang); ?></p></strong> 
      </div>
    <?php endif; ?>
       
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
       
    
</body>
</html><?php /**PATH D:\Kantor\tes\app_serve\resources\views/index.blade.php ENDPATH**/ ?>