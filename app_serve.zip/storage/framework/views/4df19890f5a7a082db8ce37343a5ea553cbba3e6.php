<table class="styled-table" style="padding-top: 120px;" >
    <thead>
        <tr>
            <td>Gambar</td>
            <td>Nama Barang</td>
            <td>No Inventaris</td>
            <td>Spesifikasi</td>
            <td>Perolehan</td>
            <td>Action</td>
            
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $databrg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $databrg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php if($databrg->gambar == ""): ?>
                <img src="<?php echo e(url('1.png', [])); ?>" alt="" width="50">
                <?php else: ?>
                <img src="<?php echo e(url('/'.$databrg->gambar, [])); ?>" alt="" width="50">
                <?php endif; ?>
              
            </td>
            <td><?php echo e($databrg->nama_barang); ?></td>
            <td><?php echo e($databrg->kd_inventaris); ?></td>
            <td>
                Merek : <?php echo e($databrg->merk); ?> <br>
                Type : <?php echo e($databrg->type); ?> <br>
                Nomor Seri : <?php echo e($databrg->no_seri); ?> <br>
                Tahun : <?php echo e($databrg->th_pembuatan); ?>

            </td>
            <td>
                Harga : <?php echo e($databrg->harga_perolehan); ?> <br>
                Tahun : <?php echo e($databrg->th_perolehan); ?> 
               
            </td>
            <td><button class="btn btn-danger btn-sm" id="hapussubtablemusnah" data-url="<?php echo e(route('hapussubtablemusnah',['id'=>$databrg->id,'no'=>$databrg->id_musnah])); ?>"><i class="fa fa-trash"></i></button></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\Kantor\tes\app_serve\resources\views/admin/form/tablebarangmusnah.blade.php ENDPATH**/ ?>