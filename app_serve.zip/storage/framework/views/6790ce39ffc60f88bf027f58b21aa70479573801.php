<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Pramita - <?php echo e(auth::user()->name); ?></title>
    <!--favicon-->
    <link rel="icon" href="<?php echo e(url('icon.png', [])); ?>" type="image/x-icon">
    <!-- simplebar CSS-->
    <link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet" />
    <!--inputtags-->
    <link href="assets/plugins/inputtags/css/bootstrap-tagsinput.css" rel="stylesheet" />
    <!--multi select-->
    <link href="assets/plugins/jquery-multi-select/multi-select.css" rel="stylesheet" type="text/css">

    <link href="assets/plugins/fancybox/css/jquery.fancybox.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <!-- Bootstrap core CSS-->
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/fontawesome.min.css"
        integrity="sha512-xX2rYBFJSj86W54Fyv1de80DWBq7zYLn2z0I9bIhQG+rxIF6XVJUpdGnsNHWRa6AvP89vtFupEPDP8eZAtu9qA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- animate CSS-->
    <link href="assets/css/animate.css" rel="stylesheet" type="text/css" />
    <!-- Icons CSS-->
    <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
    <!-- Horizontal menu CSS-->
    <link href="assets/css/horizontal-menu.css" rel="stylesheet" />
    <!-- Custom Style-->
    <link href="assets/css/app-style.css" rel="stylesheet" />

    <!--Data Tables -->
    <link href="assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
    <link href="assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="assets/plugins/jquery.steps/css/jquery.steps.css" />

</head>

<body>

    <!-- start loader -->
    
    <!-- end loader -->

    <!-- Start wrapper-->
    <div id="wrapper">

        <!--Start topbar header-->
        <header class="topbar-nav">
            <nav class="navbar navbar-expand">
                <ul class="navbar-nav mr-auto align-items-center">
                    <li class="nav-item">
                        <a class="nav-link" href="javascript:void();">
                            <div class="media align-items-center">
                                <img src="logo.png" class="logo" alt="logo icon" width="200">
                                <div class="media-body">
                                    
                                </div>
                            </div>
                        </a>
                    </li>
                    <li class="nav-item">
                        <form class="search-bar">
                            
                            
                        </form>
                    </li>
                </ul>

                <ul class="navbar-nav align-items-center right-nav-link">

                    <li class="nav-item">
                        <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" data-toggle="dropdown"
                            href="#">
                            <span class="user-profile"><img src="<?php echo e(url('icon.png', [])); ?>" class="img-circle"
                                    alt="user avatar"></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-right">
                            <li class="dropdown-item user-details">
                                <a href="javaScript:void();">
                                    <div class="media">
                                        <div class="avatar"><img class="align-self-start mr-3"
                                                src="<?php echo e(url('icon.png', [])); ?>" alt="user avatar"></div>
                                        <div class="media-body">
                                            <h6 class="mt-2 user-title"><?php echo e(auth::user()->name); ?></h6>
                                            <p class="user-subtitle"><?php echo e(auth::user()->email); ?></p>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="dropdown-divider"></li>
                            
                            <li class="dropdown-divider"></li>
                            
                            <li class="dropdown-divider"></li>
                            <li class="dropdown-item"><i class="icon-settings mr-2"></i> Setting</li>
                            <li class="dropdown-divider"></li>
                            <li class="dropdown-item"><i class="icon-power mr-2"></i><a href="http://"
                                    onclick="event.preventDefault();
          document.getElementById('logout-form').submit();">Logout</a>
                            </li>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </ul>
                    </li>
                </ul>
            </nav>
        </header>
        <!--End topbar header-->

        <!-- start horizontal Menu -->
        <nav>
            <!-- Menu Toggle btn-->
            <div class="menu-toggle">
                <h3>Pramita Inventaris</h3>
                <button type="button" id="menu-btn">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <ul id="respMenu" class="horizontal-menu">

                <li>
                    <a href="javascript:;">
                        <i class="zmdi zmdi-view-dashboard" aria-hidden="true"></i>
                        <span class="title">Dashboard</span>
                        <span class="arrow"></span>
                    </a>
                    <!-- Level Two-->
                    <ul>
                        <li><a href="<?php echo e(url('/', [])); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Home</a></li>
                        
                    </ul>
                </li>

                <li>
                    <a href="javascript:;">
                        <i class="zmdi zmdi-layers"></i>
                        <span class="title">Master Data</span>
                        <span class="arrow"></span>

                    </a>
                    <!-- Level Two-->
                    <ul>
                        <li><a href="<?php echo e(url('formbarang', [])); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Data
                                Inventaris</a></li>
                        <li><a href="<?php echo e(url('datamutasi', [])); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Form
                                Mutasi</a></li>
                        <li><a href="<?php echo e(url('datapemusnahan', [])); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Form
                                Pemusnahan</a></li>

                    </ul>
                </li>

                <li>
                    <a class="" href="javascript:;">
                        <i class="zmdi zmdi-receipt"></i>
                        <span class="title">Faq</span>
                        <span class="arrow"></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(url('formulir', [])); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Form</a>
                        </li>
                        <li><a href="<?php echo e(url('formulir1', [])); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Form 1</a>
                        </li>
                        <li><a href="<?php echo e(url('formulir2', [])); ?>"><i class="zmdi zmdi-dot-circle-alt"></i> Form 2</a>
                        </li>
                        
                    </ul>
                </li>





            </ul>
        </nav>
        <!-- end horizontal Menu -->
        <div class="clearfix"></div>

        <div class="content-wrapper">

            <?php echo $__env->yieldContent('content'); ?>





        </div>
        <!--Start Back To Top Button-->
        <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
        <!--End Back To Top Button-->

        <!--Start footer-->
        <footer class="footer">
            <div class="container">
                <div class="text-center">
                    Copyright © 2022
                </div>
            </div>
        </footer>
        <!--End footer-->

        <!--start color switcher-->
        <div class="right-sidebar">
            
            <div class="right-sidebar-content">


                <p class="mb-0">Header Colors</p>
                <hr>

                <div class="mb-3">
                    <button type="button" id="default-header" class="btn btn-outline-primary">Default
                        Header</button>
                </div>

                <ul class="switcher">
                    <li id="header1"></li>
                    <li id="header2"></li>
                    <li id="header3"></li>
                    <li id="header4"></li>
                    <li id="header5"></li>
                    <li id="header6"></li>
                </ul>

                <p class="mb-0">Sidebar Colors</p>
                <hr>

                <div class="mb-3">
                    <button type="button" id="default-sidebar" class="btn btn-outline-primary">Default
                        Header</button>
                </div>

                <ul class="switcher">
                    <li id="theme1"></li>
                    <li id="theme2"></li>
                    <li id="theme3"></li>
                    <li id="theme4"></li>
                    <li id="theme5"></li>
                    <li id="theme6"></li>
                </ul>

            </div>
        </div>
        <!--end color switcher-->

    </div>
    <!--End wrapper-->


    <!-- Bootstrap core JavaScript-->
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/script.js/2.1.1/script.min.js"
        integrity="sha512-oM6Bv767uUJZcy+SqCTP2rkHtKlivWNQ5+PPhhDwkY8FtNj4bq1xvNCB9NB3WkBa1KiY7P5a7/yfSONl5TYSPQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"
        integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- simplebar js -->
    <script src="assets/plugins/simplebar/js/simplebar.js"></script>
    <!-- horizontal-menu js -->
    <script src="assets/js/horizontal-menu.js"></script>

    <!-- Custom scripts -->
    <script src="assets/js/app-script.js"></script>

    <!-- Chart js -->
    <script src="assets/plugins/Chart.js/Chart.min.js"></script>
    <!-- Index2 js -->
    
    <script src="assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
    <script src="assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
    <script src="assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
    <script src="assets/plugins/jquery.steps/js/jquery.steps.min.js"></script>
    <script src="assets/plugins/jquery-validation/js/jquery.validate.min.js"></script>
    <!--wizard initialization-->
    <script src="assets/plugins/jquery.steps/js/jquery.wizard-init.js"></script>
    <script src="assets/plugins/fancybox/js/jquery.fancybox.min.js"></script>

    <script src="assets/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.js"></script>
    <script src="assets/plugins/bootstrap-touchspin/js/bootstrap-touchspin-script.js"></script>

    <!--Select Plugins Js-->
    <script src="assets/plugins/select2/js/select2.min.js"></script>
    <!--Inputtags Js-->
    <script src="assets/plugins/inputtags/js/bootstrap-tagsinput.js"></script>
    
    <!--Bootstrap Datepicker Js-->
    <script src="assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
    <script>
        $('#default-datepicker').datepicker({
            todayHighlight: true
        });
        $('#autoclose-datepicker').datepicker({
            autoclose: true,
            todayHighlight: true
        });

        $('#inline-datepicker').datepicker({
            todayHighlight: true
        });

        $('#dateragne-picker .input-daterange').datepicker({});
    </script>
    <script src="assets/plugins/jquery-multi-select/jquery.multi-select.js"></script>
    <script src="assets/plugins/jquery-multi-select/jquery.quicksearch.js"></script>

    <!-- Resumable JS -->
    <script src="https://cdn.jsdelivr.net/npm/resumablejs@1.1.0/resumable.min.js"></script>


    <script src="<?php echo e(url('js/scriptx.js', [])); ?>"></script>
    <script>
        $(document).ready(function() {
            $('.single-select').select2();
            $('.single-selectkode').select2();
            $('.single-selectlokasi').select2();
            $('.single-selectlokasi1').select2();
            $('.multiple-select').select2();

            //multiselect start

            $('#my_multi_select1').multiSelect();
            $('#my_multi_select2').multiSelect({
                selectableOptgroup: true
            });

            $('#my_multi_select3').multiSelect({
                selectableHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='search...'>",
                selectionHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='search...'>",
                afterInit: function(ms) {
                    var that = this,
                        $selectableSearch = that.$selectableUl.prev(),
                        $selectionSearch = that.$selectionUl.prev(),
                        selectableSearchString = '#' + that.$container.attr('id') +
                        ' .ms-elem-selectable:not(.ms-selected)',
                        selectionSearchString = '#' + that.$container.attr('id') +
                        ' .ms-elem-selection.ms-selected';

                    that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
                        .on('keydown', function(e) {
                            if (e.which === 40) {
                                that.$selectableUl.focus();
                                return false;
                            }
                        });

                    that.qs2 = $selectionSearch.quicksearch(selectionSearchString)
                        .on('keydown', function(e) {
                            if (e.which == 40) {
                                that.$selectionUl.focus();
                                return false;
                            }
                        });
                },
                afterSelect: function() {
                    this.qs1.cache();
                    this.qs2.cache();
                },
                afterDeselect: function() {
                    this.qs1.cache();
                    this.qs2.cache();
                }
            });

            $('.custom-header').multiSelect({
                selectableHeader: "<div class='custom-header'>Selectable items</div>",
                selectionHeader: "<div class='custom-header'>Selection items</div>",
                selectableFooter: "<div class='custom-header'>Selectable footer</div>",
                selectionFooter: "<div class='custom-header'>Selection footer</div>"
            });


        });
    </script>

    <script>
        $(document).ready(function() {
            //Default data table
            $('#default-datatable').DataTable();


            var table = $('#example').DataTable({
                lengthChange: false,
                buttons: ['copy', 'excel', 'pdf', 'print', 'colvis']
            });

            table.buttons().container()
                .appendTo('#example_wrapper .col-md-6:eq(0)');

        });
    </script>

    <script>
        $(document).ready(function() {
            $(document).on('click', '#lihatdatabarang', function(e) {
                delete window.browseFile288;
                delete window.resumable288;
                e.preventDefault();
                var url = $(this).data('url');
                $('#showdatabarang').html("<img src='icon.png'  style='display: block; margin: auto;'>");
                $.ajax({
                        url: url,
                        type: 'GET',
                        dataType: 'html'
                    })
                    .done(function(data) {
                        $('#showdatabarang').html(data);
                    })
                    .fail(function() {
                        $('#showdatabarang').html(
                            '<i class="fa fa-info-sign"></i> Something went wrong, Please try again...'
                            );
                    });
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $(document).on('click', '#editdatabarang', function(e) {
                e.preventDefault();
                var url = $(this).data('url');
                $('#showdatabarang').html("<img src='icon.png'  style='display: block; margin: auto;'>");
                $.ajax({
                        url: url,
                        type: 'GET',
                        dataType: 'html'
                    })
                    .done(function(data) {
                        $('#showdatabarang').html(data);
                    })
                    .fail(function() {
                        $('#showdatabarang').html(
                            '<i class="fa fa-info-sign"></i> Something went wrong, Please try again...'
                            );
                    });
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $(document).on('click', '#hapusdatabarang', function(e) {
                e.preventDefault();
                var url = $(this).data('url');
                $('#showdatabarang').html("<img src='icon.png'  style='display: block; margin: auto;'>");
                $.ajax({
                        url: url,
                        type: 'GET',
                        dataType: 'html'
                    })
                    .done(function(data) {
                        $('#showdatabarang').html(data);
                    })
                    .fail(function() {
                        $('#showdatabarang').html(
                            '<i class="fa fa-info-sign"></i> Something went wrong, Please try again...'
                            );
                    });
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $(document).on('click', '#tambahdatabarang', function(e) {
                e.preventDefault();
                var url = $(this).data('url');
                $('#showdatabarang').html("<img src='icon.png'  style='display: block; margin: auto;'>");
                $.ajax({
                        url: url,
                        type: 'GET',
                        dataType: 'html'
                    })
                    .done(function(data) {
                        $('#showdatabarang').html(data);
                    })
                    .fail(function() {
                        $('#showdatabarang').html(
                            '<i class="fa fa-info-sign"></i> Something went wrong, Please try again...'
                            );
                    });
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            $(document).on('click', '#updatedatabarang', function(e) {
                var data = $('#form-update').serialize();
                e.preventDefault();
                var url = $(this).data('url');
                $('#showdatabarang').html(
                    "<br><br><br><img src='icon.png'  style='display: block; margin: auto;'>");
                $.ajax({
                        url: url,
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf"]').attr('content')
                        },

                        type: 'POST',
                        data: data,
                        dataType: 'html'
                    })
                    .done(function(data) {
                        // console.log(data);
                        $('#showdatabarang').html(data);
                    })
                    .fail(function() {
                        $('#showdatabarang').html(
                            '<i class="fa fa-info-sign"></i> Something went wrong, Please try again...'
                            );
                    });
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            $(document).on('click', '#tambahsubdatabarang', function(e) {

                var data = $('#form-tambah').serialize();

                e.preventDefault();
                var url = $(this).data('url');
                $('#showdatabarang').html(
                    "<br><br><br><img src='icon.png'  style='display: block; margin: auto;'>");
                $.ajax({
                        url: url,
                        // headers: {'X-CSRF-TOKEN': $('meta[name="csrf"]').attr('content')},
                        type: 'POST',
                        data: data,
                        dataType: 'html'
                    })
                    .done(function(data) {
                        // console.log(data);
                        $('#showdatabarang').html(data);
                    })
                    .fail(function() {
                        console.log(data);
                        $('#showdatabarang').html('<i class="fa fa-info-sign"></i> Gagal Baca');
                    });
            });
        });
    </script>


    <script>
        $(document).ready(function() {
            $(document).on('click', '#mutasidatabarang', function(e) {
                e.preventDefault();
                var url = $(this).data('url');
                $('#showdatabarang').html("<img src='icon.png'  style='display: block; margin: auto;'>");
                $.ajax({
                        url: url,
                        type: 'GET',
                        dataType: 'html'
                    })
                    .done(function(data) {
                        $('#showdatabarang').html(data);
                    })
                    .fail(function() {
                        $('#showdatabarang').html(
                            '<i class="fa fa-info-sign"></i> Something went wrong, Please try again...'
                            );
                    });
            });
        });
    </script>
   




    
</body>

</html>
<?php /**PATH D:\Kantor\tes\app_serve\resources\views/layouts/app.blade.php ENDPATH**/ ?>