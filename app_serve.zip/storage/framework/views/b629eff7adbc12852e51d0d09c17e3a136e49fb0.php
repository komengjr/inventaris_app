<style>
    .modal-admin {
/* new custom width */
    width: 75%;
    }
</style>
<script src="assets/plugins/alerts-boxes/js/sweetalert.min.js"></script>
<script src="assets/plugins/alerts-boxes/js/sweet-alert-script.js"></script>
<script type="text/javascript">
    function submitForm()
    {
    document.form1.target = "myActionWin";
    window.open("","myActionWin","width=1000,height=700,toolbar=0");
    document.form1.submit();
    }
    </script>
<div class="modal-content" id="showdatabarang">
   <div class="modal-header">
        
        <button class="btn btn-success btn-sm" id="tambahdatabarang" data-url="<?php echo e(route('tambahdatabarang',['id'=>$id])); ?>"><i class="fa fa-plus"> Tambah Data Barang</i>  </button>
        <span>
            <button  type="button" class="btn-outline-primary" data-toggle="modal" data-target="#printdata"><i class="fa fa-print"> Print Barcode <?php echo e($id); ?></i></button>
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal" aria-label="Close">
            <i class="fa fa-close"></i>
        </button>
        </span>
    </div>
    <div class="body" id="showdatabarang">
        
    
        <div class="row" >
            <div class="col-lg-12">
               
                <div class="card-body">
                    <?php if(session()->has('status')): ?>
                    <div class="alert alert-success alert-dismissible alert-sm" role="alert">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <div class="alert-icon contrast-alert">
                        <i class="fa fa-check"></i>
                        </div>
                        <div class="alert-message">
                        <span><strong>Success!</strong>  <?php echo e(session()->get('status')); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>
                <div class="table-responsive" style="letter-spacing: .0px;">
                    <table id="default-datatable1" class="table table-bordered" >
                    <thead>
                        <tr>
                            
                            <th>Gambar</th>
                            <th>Kode Inventaris</th>
                            <th>Lokasi</th>
                            
                            <th>Tahun Pembelian</th>
                            <th>Nama Barang</th>
                            <th>Qr Code</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php
                        $nama_lokasi = DB::table('tbl_lokasi')
                        ->select('tbl_lokasi.nama_lokasi')
                        ->where('kd_lokasi',$data->kd_lokasi)
                        ->get();
                       ?>
                        <tr>
                            
                            <td>
                                <?php if($data->gambar == ""): ?>
                                <a href="https://via.placeholder.com/1920x1080"  data-fancybox="images" data-caption="<?php echo e($data->nama_barang); ?>" >
                                    <img src="https://via.placeholder.com/800x500" alt="lightbox" class="lightbox-thumb img-thumbnail" id="videoPreview"  width="50" height="50">
                                </a>
                                <?php else: ?>
                                <a href="<?php echo e(url($data->gambar, [])); ?>"  data-fancybox="images" data-caption="<?php echo e($data->nama_barang); ?>">
                                    <img src="<?php echo e(url($data->gambar, [])); ?>" alt="lightbox" class="lightbox-thumb img-thumbnail" id="videoPreview" width="50" height="50">
                                </a>   
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($data->kd_inventaris); ?></td>
                            <?php if($nama_lokasi->isEmpty()): ?>
                            <td><?php echo e($data->kd_lokasi); ?></td>
                            <?php else: ?>
                            <td><?php echo e($data->kd_lokasi); ?> ( <?php echo e($nama_lokasi[0]->nama_lokasi); ?> )</td>
                            <?php endif; ?>
                           
                            
                            <td><?php echo e($data->th_pembuatan); ?></td>
                            <td><?php echo e($data->nama_barang); ?></td>
                            <?php if($data->kd_lokasi == "-"): ?>
                            <td>Kosong</td> 
                            <?php else: ?>
                            <td class="text-center"><?php echo QrCode::size(90)->generate(url("view",['no'=>substr($data->kd_inventaris,0,2),'cb'=>$data->kd_cabang,'kd'=>$data->kd_inventaris,'id'=>$data->id]));; ?></td>
                            <?php endif; ?>
                            
                            <td>
                                <button class="btn btn-info btn-sm" id="editdatabarang" data-url="<?php echo e(route('editdatabarang1',['id' => $data->id])); ?>"><i class="fa fa-eye"> Lihat Data</i></button><br><br>
                                
                                <a class="tombolhapus<?php echo e($data->id); ?> btn btn-danger" style="display: none;" id="hapusdatabarang" data-url="<?php echo e(route('hapusdatabarang',['kode' => $data->kd_inventaris,'id' => $data->id])); ?>"></a>
                            </td>
                        </tr>
                            
                        <script>
                            $("#confirm-btn-hapus<?php echo $data->id ?>").click(function(){
                            swal({
                                title: "Yakin Untuk Di Hapus ?",
                                text: "Once deleted, you will not be able to recover this imaginary file!",
                                icon: "warning",
                                buttons: true,
                                dangerMode: true,
                            })
                            .then((willDelete) => {
                            if (willDelete) {
                                swal("Poof! Your imaginary file has been deleted!", {
                                icon: "success",
                                });
                                document.getElementsByClassName('tombolhapus<?php echo $data->id ?>')[0].click();
                            } else {
                                swal("Your imaginary file is safe!");
                            }
                            });

                            });
                        </script>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                   
                    </table>
                </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-dark" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        
    </div>
</div>

<div class="modal fade" id="printdata">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content border-primary ">
        <div class="modal-header bg-primary ">
          <h5 class="modal-title text-white">From Print Data</h5>
          <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form name="form1" action="<?php echo e(url('pdf',['id'=>$id])); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="modal-body">
            
                    <div class="row">
                        <div class="col-6">
                            <label for="input-1">Ukuran</label>
                            <select name="ukuran" id="" class="form-control" required>
                                <option value="">Pilih Ukuran</option>
                                <option value="A4">A4</option>
                                <option value="A5">A5</option>
                                <option value="A6">A6</option>
                                <option value="A7">A7</option>
                                <option value="A8">A8</option>
                            </select>
                        </div>
                       <div class="col-6">
                        <label for="input-1">Layout</label>
                            <select name="layout" id="" class="form-control" required>
                               
                                <option value="Portrait">Portrait</option>
                                <option value="landscape">Landscape</option>
                            </select>
                       </div>
                    </div>
                
        </div>
        <div class="modal-footer bg-primary">
          
          
          <a type="submit" class="btn btn-success" onclick="submitForm()"> Cetak</i></a>
          
        </div>
        </form>
      </div>
    </div>
  </div><!--End Modal -->

  <script>
   $(document).ready(function() {
        $('#myform').submit(function() {
            window.open('', 'formpopup', 'width=400,height=400,resizeable,scrollbars');
            this.target = 'formpopup';
        });
    });
  </script>

<script>
    $(document).ready(function() {
    //Default data table
    $('#default-datatable1').DataTable();


    var table = $('#example').DataTable( {
    lengthChange: false,
    buttons: [ 'copy', 'excel', 'pdf', 'print', 'colvis' ]
    } );

    table.buttons().container()
    .appendTo( '#example_wrapper .col-md-6:eq(0)' );
    
    } );

</script>
<?php /**PATH D:\Kantor\tes\app_serve\resources\views/admin/sub_barang1.blade.php ENDPATH**/ ?>