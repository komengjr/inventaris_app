<div class="row">
    <?php if($id == 0): ?>
        
    <?php elseif($id == 1): ?>
    <input type="text" class="form-control" value="-"  id="asal_lokasi" name="asal_lokasi" hidden>      
    <input type="text" class="form-control" value="-"  id="target_lokasi" name="target_lokasi" hidden>
    <?php elseif($id == 2): ?>
    <input type="text" class="form-control" value="-"  id="asal_lokasi" name="asal_lokasi" hidden>      
    <input type="text" class="form-control" value="-"  id="target_lokasi" name="target_lokasi" hidden>
    <?php elseif($id == 3): ?>
    <input type="text" class="form-control" value="-"  id="asal_lokasi" name="asal_lokasi" hidden>      
    <input type="text" class="form-control" value="-"  id="target_lokasi" name="target_lokasi" hidden>
    <?php elseif($id == 4): ?>

    <div class="col-6">
        <label for="">Asal Cabang</label>
        <?php
        $lokasigue = DB::table('tbl_cabang')
        ->select('tbl_cabang.*')
        ->where('kd_cabang',auth::user()->cabang) 
        ->get();
        ?>
        <input type="text" class="form-control" value="<?php echo e($lokasigue[0]->nama_cabang); ?>" name="asal_lokasi" id="asal_lokasi">
    </div>
    <div class="col-6">
        <label for="">Target Cabang</label>
        <select class="form-control single-lokasi" name="target_lokasi" id="target_lokasi">
            <option value="">Pilih Lokasi</option>
            <?php
            $lokasi = DB::table('tbl_cabang')
            ->select('tbl_cabang.*')
            ->get();
            ?>
            <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($lokasi->kd_cabang == auth::user()->cabang): ?>
                    
                <?php else: ?>
                    <option value="<?php echo e($lokasi->kd_cabang); ?>"><?php echo e($lokasi->nama_cabang); ?></option>
                <?php endif; ?>
                    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </select>
    </div> 

    <?php endif; ?>
   
</div>
<script>
    $(document).ready(function() {
        $('.single-lokasi').select2();

    });
</script><?php /**PATH D:\Kantor\tes\app_serve\resources\views/admin/form/jenis_mutasi.blade.php ENDPATH**/ ?>