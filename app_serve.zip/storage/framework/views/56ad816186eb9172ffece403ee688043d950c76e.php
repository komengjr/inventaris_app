<div class="card-body">
    <div class="row">
        <div class="col-md-4">
            <label for="">Lokasi barang</label>
            <select class="form-control single-selectq" name="kd_inventaris" id="greet1" onchange="getOption1()">
                <option>Pilih Lokasi</option>
                <?php $__currentLoopData = $data_lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option  value="<?php echo e(url('selectlokasi1', ['id'=>$data_lokasi->kd_lokasi ,'kd'=>$id])); ?>">- <?php echo e($data_lokasi->nama_lokasi); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-8" id="selectlokasixx1">
            
        </div>
        
        
    </div>
</div>
<script>
    $(document).ready(function() {
        $('.single-select').select2();
        $('.single-selectq').select2();

    });
</script><?php /**PATH D:\Kantor\tes\app_serve\resources\views/admin/form/tbl_pemusnahan.blade.php ENDPATH**/ ?>