<table class="styled-table" style="padding-top: 120px;" id="kliktambahbrgmutasix">
    <thead>
        <tr>
            <td>Gambar</td>
            <td>Nama Barang</td>
            <td>No Inventaris</td>
            <td>Spesifikasi</td>
            <td>Perolehan</td>
            <td>Lokasi</td>
            <td>Action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $databrg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $databrg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php if($databrg->gambar == ""): ?>
                <img src="<?php echo e(url('1.png', [])); ?>" alt="" width="50">
                <?php else: ?>
                <img src="<?php echo e(url('/'.$databrg->gambar, [])); ?>" alt="" width="50">
                <?php endif; ?>
              
            </td>
            <td><?php echo e($databrg->nama_barang); ?></td>
            <td><?php echo e($databrg->kd_inventaris); ?></td>
            <td>
                Merek : <?php echo e($databrg->merk); ?> <br>
                Type : <?php echo e($databrg->type); ?> <br>
                Nomor Seri : <?php echo e($databrg->no_seri); ?> <br>
                Tahun : <?php echo e($databrg->th_pembuatan); ?>

            </td>
            <td>
                Harga : <?php echo e($databrg->harga_perolehan); ?> <br>
                Tahun : <?php echo e($databrg->th_perolehan); ?> 
               
            </td>
            <td>
                <?php $lok1 = DB::select('select * from tbl_lokasi where kd_lokasi = "'. $databrg->kd_lokasi_awal.'"',[0]) ?>
                Asal Lokasi <br>
                Cabang : <?php echo e($databrg->kd_cabang_awal); ?> <br>
                Ruang : <?php echo e($lok1[0]->nama_lokasi); ?> <br>
                <?php $lok2 = DB::select('select * from tbl_lokasi where kd_lokasi = "'. $databrg->kd_lokasi_tujuan.'"',[0]) ?>
                Target Lokasi : <br>
                Cabang : <?php echo e($databrg->kd_cabang_tujuan); ?> <br>
                Ruang : <?php echo e($lok2[0]->nama_lokasi); ?> 
            </td>
            <td><button class="btn btn-danger btn-sm"  id="hapussubtablemutasi" data-url="<?php echo e(route('hapussubtablemutasi',['id'=>$databrg->id,'no'=>$databrg->id_mutasi])); ?>"><i class="fa fa-trash"></i></button></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\Kantor\tes\app_serve\resources\views/admin/form/tablebarangmutasi.blade.php ENDPATH**/ ?>