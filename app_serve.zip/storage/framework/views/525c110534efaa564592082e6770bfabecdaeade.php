<table  style="table-layout: auto;">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr >
            <td style="padding-right:6px; padding-top: 0%; padding-left: 0%; "><?php echo QrCode::size(90)->generate($data->kd_inventaris);; ?> </td>
            
        </tr>
        <tr style="">
            <td ><strong><p style="font-size: 9px; text-align: center; ">  <?php echo e($data->nama_barang); ?></p></strong></td>
           <p></p>
        </tr>
       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH D:\Kantor\tes\app_serve\resources\views/admin/print.blade.php ENDPATH**/ ?>