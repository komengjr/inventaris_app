<div class="table-responsive" id="showdatamusnah">
    <table id="default-datatable" class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>No Mutasi</th>
                <th>Tanggal Buat</th>                  
                <th>Penggagas</th>
                <th>Spv SDM & Umum</th>
                <th>Persetujuan</th>
                <th class="text-center">Action</th>
            
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>1</td>
                <td><?php echo e($data->no_surat); ?></td>
                <td><?php echo e($data->tgl_buat); ?></td>
                <td><?php echo e($data->penggagas); ?></td>
                <td><?php echo e($data->user_verifikasi); ?></td>
                <td><?php echo e($data->user_persetujuan); ?></td>
                <td class="text-center"><button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#tambahbarangbaru" id="tambahbarangbarux" data-url="<?php echo e(route('tampilformmuitasi',['id' => $data->id_musnah])); ?>"><i class="fa fa-pencil"> Input Barang</i></button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
</div>
<script>
    $(document).ready(function() {
        //Default data table
        $('#default-datatable').DataTable();


      

    });
</script><?php /**PATH D:\Kantor\tes\app_serve\resources\views/admin/form/tablepemusnahan.blade.php ENDPATH**/ ?>