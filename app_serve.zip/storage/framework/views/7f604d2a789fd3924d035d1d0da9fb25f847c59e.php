   
 <?php $__env->startSection('content'); ?>
     

        <?php if(Auth::user()->akses == "admin"): ?>
        <?php echo $__env->make('admin.view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
        <?php echo $__env->make('admin.view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kantor\tes\app_serve\resources\views/home.blade.php ENDPATH**/ ?>