<?php
use App\Http\Controllers\FileUploadController;
use Illuminate\Support\Facades\Route;


// Admin Controller
//Mutasi
Route::get('/datamutasi', 'AdminController@formmutasi');
Route::get('tampilformmuitasi/{id}',['as'=>'tampilformmuitasi','uses'=> 'AdminController@tampilformmuitasi']);
Route::get('tambahsubdatamutasibarangx/{id}',['as'=>'tambahsubdatamutasibarangx','uses'=> 'AdminController@tambahsubdatamutasibarangx']);
Route::get('selectlokasi/{id}/{kd}',['as'=>'selectlokasi','uses'=> 'AdminController@selectlokasi']);
Route::post('inputdatamutasibaru',['as'=>'inputdatamutasibaru','uses'=> 'AdminController@inputdatamutasibaru']);
Route::post('kliktambahbrgmutasi/{id}',['as'=>'kliktambahbrgmutasi','uses'=> 'AdminController@kliktambahbrgmutasi']);
Route::get('hapussubtablemutasi/{id}/{no}',['as'=>'hapussubtablemutasi','uses'=> 'AdminController@hapussubtablemutasi']);
Route::get('jenis_mutasi/{id}',['as'=>'jenis_mutasi','uses'=> 'AdminController@jenis_mutasi']);

Route::get('printdokumenmutasi/{id}', 'PdfController@printdokumenmutasi');
Route::get('printdokumenmutasi', 'PdfController@printdokumenmutasi1');

Route::post('file-upload-dokumenmutasi/{id}', [FileUploadController::class, 'uploadDokumenMutasi'])->name('files.upload.dokumenmutasi');
//Musnah
Route::get('/datapemusnahan', 'AdminController@formmusnah');
Route::get('xxshowdatamusnah/{id}',['as'=>'xxshowdatamusnah','uses'=> 'AdminController@xxshowdatamusnah']);
Route::get('addpemusnahanbarang/{id}',['as'=>'addpemusnahanbarang','uses'=> 'AdminController@addpemusnahanbarang']);
Route::post('inputdatamusnahbaru',['as'=>'inputdatamusnahbaru','uses'=> 'AdminController@inputdatamusnahbaru']);
Route::get('selectlokasi1/{id}/{kd}',['as'=>'selectlokasi1','uses'=> 'AdminController@selectlokasi1']);
Route::post('kliktambahbrgmusnah/{id}',['as'=>'kliktambahbrgmusnah','uses'=> 'AdminController@kliktambahbrgmusnah']);
Route::get('hapussubtablemusnah/{id}/{no}',['as'=>'hapussubtablemusnah','uses'=> 'AdminController@hapussubtablemusnah']);
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('formulir', function () {
    return view('admin.formformulir');
});
Route::get('formulir1', function () {
    return view('form.formformulir1');
});
Route::get('formulir2', function () {
    return view('form.formformulir2');
});

// Route::get('/pdf', 'PdfController@print')->name('print');
Route::post('/pdf/{id}', 'PdfController@print');
Route::post('/printbarcodelokasi', 'PdfController@printbarcodelokasi');
Route::get('/printpeserta', 'PdfController@printpeserta');

Route::get('print/{id}', 'DataTableController@print');
Route::get('formbarang', 'DataTableController@formbarang');
Route::post('simpanjenisbarang', 'DataTableController@simpanjenisbarang');
Route::post('simpandetailbarang', 'DataTableController@simpandetailbarang');
Route::post('simpanlokasi', 'DataTableController@simpanlokasi');
Route::post('simpannourutbarang', 'DataTableController@simpannourutbarang');
Route::post('simpanpeserta', 'DataTableController@simpanpeserta');
Route::post('simpandatapeserta', 'DataTableController@simpandatapeserta');

Route::post('updatedatabarang/{id}',['as'=>'updatedatabarang','uses'=> 'HomeController@updatedatabarang']);
Route::post('updatedatabarang1/{id}',['as'=>'updatedatabarang1','uses'=> 'HomeController@updatedatabarang1']);

Route::post('simpandatasubbarang/{id}',['as'=>'simpandatasubbarang','uses'=> 'HomeController@simpandatasubbarang']);
Route::post('simpandatasubbarang1/{id}',['as'=>'simpandatasubbarang1','uses'=> 'HomeController@simpandatasubbarang1']);

Route::get('import', 'DataTableController@importData');
Route::post('import', 'DataTableController@import');
Auth::routes();

Route::get('/', 'HomeController@index')->name('home');
Route::get('/home', 'HomeController@index')->name('home');
Route::get('lihatdatabarang/{id}',['as'=>'lihatdatabarang','uses'=> 'HomeController@lihatdatabarang']);
Route::get('lihatdatabarang1/{id}',['as'=>'lihatdatabarang1','uses'=> 'HomeController@lihatdatabarang1']);
Route::get('editdatabarang/{id}',['as'=>'editdatabarang','uses'=> 'HomeController@editdatabarang']);
Route::get('editdatabarang1/{id}',['as'=>'editdatabarang1','uses'=> 'HomeController@editdatabarang1']);
Route::get('hapusdatabarang/{kode}/{id}',['as'=>'hapusdatabarang','uses'=> 'HomeController@hapusdatabarang']);
Route::get('tambahdatabarang/{id}',['as'=>'tambahdatabarang','uses'=> 'HomeController@tambahdatabarang']);


Route::get('mutasidatabarang/{id}',['as'=>'mutasidatabarang','uses'=> 'HomeController@mutasidatabarang']);




Route::get('file-upload', [FileUploadController::class, 'index'])->name('files.index');
Route::post('file-upload/upload-large-files/{id}', [FileUploadController::class, 'uploadLargeFiles'])->name('files.upload.large');
Route::post('file-upload/upload-large-files', [FileUploadController::class, 'uploadLargeFiles1'])->name('files.upload.large1');


Route::get('view/{no}/{cb}/{kd}/{id}', 'DataController@showdata');












Route::get('registerpasien', function () {
    return view('form.formregispasien');
});
Route::get('viewregistrasi/{id}', 'DataTableController@viewdatapasien');
Route::post('simpandataregsiter',['as'=>'simpandataregsiter','uses'=> 'DataController@simpandataregsiter']);