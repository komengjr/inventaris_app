<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePasienBaruTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pasien_baru', function (Blueprint $table) {
            $table->id();
            $table->string('no_registerasi')->unique();
            $table->string('nama_pasien');
            $table->string('job');
            $table->string('nik');
            $table->string('umur');
            $table->string('jk');
            $table->string('divisi');
            $table->string('lokasi');
            $table->string('tgl_pemeriksaan');
            $table->string('dokter_pemeriksa');
            $table->string('kel_1')->nullable();
            $table->string('ket_kel_1')->nullable();
            $table->string('kel_2')->nullable();
            $table->string('ket_kel_2')->nullable();
            $table->string('kel_3')->nullable();
            $table->string('ket_kel_3')->nullable();
            $table->string('kel_4')->nullable();
            $table->string('ket_kel_4')->nullable();
            $table->string('kel_5')->nullable();
            $table->string('ket_kel_5')->nullable();
            $table->string('kel_6')->nullable();
            $table->string('ket_kel_6')->nullable();
            $table->string('kel_7')->nullable();
            $table->string('ket_kel_7')->nullable();
            $table->string('kel_8')->nullable();
            $table->string('ket_kel_9')->nullable();
            $table->string('kel_10')->nullable();
            $table->string('ket_kel_10')->nullable();
            $table->string('kel_11')->nullable();
            $table->string('ket_kel_11')->nullable();
            $table->string('kel_12')->nullable();
            $table->string('ket_kel_12')->nullable();
            $table->string('kel_13')->nullable();
            $table->string('ket_kel_13')->nullable();
            $table->string('kel_14')->nullable();
            $table->string('ket_kel_14')->nullable();
            $table->string('kel_15')->nullable();
            $table->string('ket_kel_15')->nullable();
            $table->string('kel_16')->nullable();
            $table->string('ket_kel_16')->nullable();
            $table->string('kel_17')->nullable();
            $table->string('ket_kel_17')->nullable();
            $table->string('kel_18')->nullable();
            $table->string('ket_kel_18')->nullable();
            $table->string('kel_19')->nullable();
            $table->string('ket_kel_19')->nullable();
            $table->string('kel_20')->nullable();
            $table->string('ket_kel_20')->nullable();
            $table->string('kel_21')->nullable();
            $table->string('ket_kel_21')->nullable();
            $table->string('kel_22')->nullable();
            $table->string('ket_kel_22')->nullable();
            $table->string('kel_23')->nullable();
            $table->string('ket_kel_23')->nullable();
            $table->string('kel_24')->nullable();
            $table->string('ket_kel_24')->nullable();
            $table->string('kel_25')->nullable();
            $table->string('ket_kel_25')->nullable();
            $table->string('kel_26')->nullable();
            $table->string('ket_kel_26')->nullable();
            $table->string('kel_27')->nullable();
            $table->string('ket_kel_27')->nullable();
            $table->string('kel_28')->nullable();
            $table->string('ket_kel_28')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pasien_baru');
    }
}
