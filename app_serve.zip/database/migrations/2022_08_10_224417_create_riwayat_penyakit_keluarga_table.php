<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRiwayatPenyakitKeluargaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('riwayat_penyakit_keluarga', function (Blueprint $table) {
            $table->id();
            $table->string('no_registerasi');
            $table->string('pk_diabetes')->nullable();
  
            $table->string('pk_hypertensi')->nullable();
  
            $table->string('pk_stroke')->nullable();
      
            $table->string('pk_jantung')->nullable();
            $table->string('pk_ginjal')->nullable();
         
            $table->string('pk_tbc')->nullable();
       
            $table->string('pk_lepra')->nullable();
       
            $table->string('pk_hepatitis')->nullable();
        
            $table->string('pk_epilepsi')->nullable();
      
            $table->string('pk_kejiwaan')->nullable();
         
            $table->string('pk_kanker')->nullable();
         
            $table->string('pk_lupus')->nullable();
        
            $table->string('pk_asma')->nullable();
        
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('riwayat_penyakit_keluarga');
    }
}
