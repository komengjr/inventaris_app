<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRiwayatPenyakitTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('riwayat_penyakit', function (Blueprint $table) {
            $table->id();
            $table->string('no_registerasi');
            $table->string('gastritis')->nullable();
  
            $table->string('hepatitis')->nullable();
  
            $table->string('batu_empedu')->nullable();
      
            $table->string('demam_typoid')->nullable();
         
            $table->string('haemorrid')->nullable();
       
            $table->string('osp')->nullable();
       
            $table->string('asma')->nullable();
        
            $table->string('tbc')->nullable();
      
            $table->string('batuk_lebih')->nullable();
         
            $table->string('pneumonia')->nullable();
         
            $table->string('jantung')->nullable();
        
            $table->string('hipertensi')->nullable();
        
            $table->string('stroke')->nullable();
       
            $table->string('pen')->nullable();
        
            $table->string('anemia')->nullable();
        
            $table->string('vertigo')->nullable();
        
            $table->string('epilepsi')->nullable();
        
            $table->string('polio')->nullable();
    
            $table->string('kejiwaan')->nullable();
         
            $table->string('cidera_kepala')->nullable();
        
            $table->string('mata_minus')->nullable();
        
            $table->string('mata_plus')->nullable();
         
            $table->string('mata_slinder')->nullable();
         
            $table->string('trauma_pengelihatan')->nullable();
        
            $table->string('fotopobia')->nullable();
        
            $table->string('pendengaran')->nullable();
        
            $table->string('sinusitis')->nullable();
         
            $table->string('rhinitis')->nullable();
        
            $table->string('amandel')->nullable();
        
            $table->string('otitis')->nullable();
         
            $table->string('trauma_pendengaran')->nullable();
         
            $table->string('batu_ginjal')->nullable();
        
            $table->string('penyakit_ginjal')->nullable();
        
            $table->string('isk')->nullable();
         
            $table->string('osk')->nullable();
        
            $table->string('patah_tulang')->nullable();
         
            $table->string('radang_sendi')->nullable();
         
            $table->string('rheumatik')->nullable();
         
            $table->string('cidera')->nullable();
       
            $table->string('nyeri_otot')->nullable();
        
            $table->string('nyeri_punggung')->nullable();
        
            $table->string('gar')->nullable();
        
            $table->string('kista')->nullable();
         
            $table->string('pahs')->nullable();
        
            $table->string('hiv')->nullable();
        
            $table->string('lepra')->nullable();
        
            $table->string('pkyl')->nullable();
        
            $table->string('diabetes')->nullable();
        
            $table->string('gondok')->nullable();
        
            $table->string('alergi_obat')->nullable();
        
            $table->string('alergi_makanan')->nullable();
        
            $table->string('alergi_hirupan')->nullable();
        
            $table->string('alergi_kontak')->nullable();
         
            $table->string('alergi_lain')->nullable();
        
            $table->string('dhf')->nullable();
        
            $table->string('malaria')->nullable();
        
            $table->string('typoid')->nullable();
       
            $table->string('tropis_lain')->nullable();
        
            $table->string('kanker')->nullable();
     
            $table->string('leukimia')->nullable();
     
            $table->string('pernah_oprasi')->nullable();
      
            $table->string('penyakit_lain')->nullable();
          
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('riwayat_penyakit');
    }
}
