<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRiwayatKebiasaanHidupTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('riwayat_kebiasaan_hidup', function (Blueprint $table) {
            $table->id();
            $table->string('no_registerasi');
            $table->string('minum_alkohol')->nullable();
            $table->string('ket_minum_alkohol')->nullable();
            $table->string('olahraga')->nullable();
            $table->string('ket_olahraga')->nullable();
            $table->string('merokok')->nullable();
         
            $table->string('ket_merokok')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('riwayat_kebiasaan_hidup');
    }
}
